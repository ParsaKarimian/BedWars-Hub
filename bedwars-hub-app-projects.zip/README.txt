BedWars Hub - app projects (Android APK + Windows EXE)
The site domain is set in two places: android/app/src/main/java/com/bedwarshub/app/MainActivity.java (SITE, HOST) and windows/main.js (SITE, OK). Change karimal.ir if needed.

WINDOWS .exe (needs Node 18+):  cd windows && npm install && npm run dist   -> windows/dist/BedWars Hub Setup 1.0.0.exe
ANDROID .apk (needs Android Studio): open the android folder, wait for Gradle sync, Build > Build APK(s)  -> app/build/outputs/apk/debug/app-debug.apk
Or without installing anything: put this folder on GitHub; the workflow in .github/workflows builds both and offers them as downloadable artifacts (Actions tab).
The debug APK installs directly (enable "install unknown apps"). For Google Play you must sign a release build.
